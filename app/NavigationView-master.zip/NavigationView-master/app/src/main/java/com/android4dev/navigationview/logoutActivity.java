package com.android4dev.navigationview;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by kartvyasinh vaghela on 3/18/2017.
 */

public class logoutActivity extends AppCompatActivity {
    @Override
    public void finish() {
        super.finish();

    }
}
